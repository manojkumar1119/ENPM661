//Libs used
#include <memory>
#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
//library for time sleep
#include <chrono>

//Main function
int main(int argc, char * argv[])
{
  // InitializeROS and node is cretaed
  rclcpp::init(argc, argv);
  //node setting
  auto const node = std::make_shared<rclcpp::Node>("package_120511257",rclcpp::NodeOptions().automatically_declare_parameters_from_overrides(true));

  // Logging for ROS
  auto const logger = rclcpp::get_logger("package_120511257");

  //Creating moveit interface for hands and arm
  using moveit::planning_interface::MoveGroupInterface;
  auto move_group_interface = MoveGroupInterface(node, "panda_arm");   //Arm
  auto move_group_gripper   = MoveGroupInterface(node, "panda_hand");  //Hand
  
  // Setting  a goal state 1 orientation and position
  auto const goal_state_1 = []{
    geometry_msgs::msg::Pose msg;
    msg.orientation.x = 1.0;
    msg.orientation.y = 0;
    msg.orientation.z = 0;
    msg.orientation.w = 0;
    msg.position.x = 0.7;
    msg.position.y = 0.0;
    msg.position.z = 0.59;
    return msg;
  }();

  // Setting  a goal state 2 orientation and position
  auto const goal_state_2 = []{
    geometry_msgs::msg::Pose msg;
    msg.orientation.x = 1.0;
    msg.orientation.y = 0;
    msg.orientation.z = 0;
    msg.orientation.w = 0;
    msg.position.x = -0.7;
    msg.position.y = -0.1;
    msg.position.z = 0.59;
    return msg;
  }();

  //Setting target ad goal state1
  move_group_interface.setPoseTarget(goal_state_1);
  
  // Create a plan to goal_state_1
  auto const [success, plan] = [&move_group_interface]{
    moveit::planning_interface::MoveGroupInterface::Plan msg;
    auto const ok = static_cast<bool>(move_group_interface.plan(msg));
    return std::make_pair(ok, msg);
  }();
  
  // Execute the plan for goal_state_1 if no collision
  if(success) 
  {
     //Initially open griiper
    //Time delay seep
    std::this_thread::sleep_for(std::chrono::seconds(3));
    RCLCPP_INFO(logger, "Gripper opened!!!!!!!!");
    move_group_gripper.setNamedTarget("open_gripper");
    bool grip_status_open = static_cast<bool>(move_group_gripper.move());
   //If error disp the status
   if (!grip_status_open) 
   {
      RCLCPP_ERROR(logger, "Failed to Open the gripper!!!");
    }

   //Moving to Goal state 1
   RCLCPP_INFO(logger, "Planning successfull to goal_state_1!!!");
   RCLCPP_INFO(logger, "Moving to Goal State 1");
   std::this_thread::sleep_for(std::chrono::seconds(3));
   //Execute the plan
   move_group_interface.execute(plan);

   //Closing the gripper
   //Time delay seep 3 s
   std::this_thread::sleep_for(std::chrono::seconds(3));
   RCLCPP_INFO(logger, "Gripper Closed!!!!!!!!");
   move_group_gripper.setNamedTarget("close_gripper");                //Target as robot pose close_gripper
   bool grip_status_close = static_cast<bool>(move_group_gripper.move());
   //If error disp the status
   if (!grip_status_close) 
   {
      RCLCPP_ERROR(logger, "Failed to CLose the gripper!!!");
    }
  }
  else 
  {
    RCLCPP_ERROR(logger, "Planing failed for goal_state_1!!!");
  }

  //sleep for 3 seconds and set the trget as goal state2
  std::this_thread::sleep_for(std::chrono::seconds(3));
  move_group_interface.setPoseTarget(goal_state_2);
  
  // Create a plan to goal_state_2
  auto const [success1, plan1] = [&move_group_interface]{
    moveit::planning_interface::MoveGroupInterface::Plan msg;
    auto const ok1 = static_cast<bool>(move_group_interface.plan(msg));
    return std::make_pair(ok1, msg);
  }();

  // Execute the plan for goal_state_2 is no collision
  if(success1) 
  {
   //Moving to Goal state 2
   RCLCPP_INFO(logger, "Planning successfull to goal_state_2!!!");   //LOGGER
   RCLCPP_INFO(logger, "Moving to Goal State 2");                    //LOGGER
   move_group_interface.execute(plan1);

   //Opening the gripper
   //Time delay seep 3 s
   std::this_thread::sleep_for(std::chrono::seconds(3));
   RCLCPP_INFO(logger, "Gripper Opened!!!!!!!!");
   move_group_gripper.setNamedTarget("open_gripper");                //Target as robot pose open_gripper
   bool grip_status_open = static_cast<bool>(move_group_gripper.move());
   //If error disp the status
   if (!grip_status_open) 
   {
      RCLCPP_ERROR(logger, "Failed to OPen the gripper!!!");         //ERROR Logger
    }
  }
  else 
  {
    RCLCPP_ERROR(logger, "Planing failed for goal_state_2!!!");      //ERROR Logger
  }

  std::this_thread::sleep_for(std::chrono::seconds(3));
  //Moving to initial state
   move_group_interface.setNamedTarget("home_state");                //Initial state as home_state

   // Create a plan to initial_state
  auto const [success2, plan2] = [&move_group_interface]{
  moveit::planning_interface::MoveGroupInterface::Plan msg;
  auto const ok2 = static_cast<bool>(move_group_interface.plan(msg));
  return std::make_pair(ok2, msg);
  }();

  if(success2) 
  {
   RCLCPP_INFO(logger, "Moving to Initial_state");                   //INFO
   //execute plan to initila state
   move_group_interface.execute(plan2);
  }
  else
  {
    RCLCPP_ERROR(logger, "Planing failed for Initial state!!!");     //ERROR logger
  } 
  // ShutdownROS
  rclcpp::shutdown();

  return 0;
}

               

